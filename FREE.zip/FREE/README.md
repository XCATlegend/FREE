# titanx_g2
Ya, Titanx gen2.
